# Check Graph

You can use this package for recognisation of various graph classes.
